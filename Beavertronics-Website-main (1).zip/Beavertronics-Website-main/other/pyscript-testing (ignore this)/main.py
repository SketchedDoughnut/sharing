import pyscript
def email(): # I was messing around with emailing, ignore this
    # Import smtplib for the actual sending function
    import smtplib

    # Import the email modules we'll need
    from email.message import EmailMessage

    email = pyscript.document.querySelector("#email")
    email = email.value
    email = 'yourmom'
    # set the msg content??
    msg = EmailMessage()
    msg.set_content(email)

    # me == the sender's email address
    # you == the recipient's email address
    me = 'apanjala@hotmail.com'
    you = 'apanjala@hotmail.com'

    msg['Subject'] = f'The contents of your mother'
    msg['From'] = me
    msg['To'] = you

    # Send the message via our own SMTP server.
    #s = smtplib.SMTP('1510')
    #s.send_message(msg)
    #s.quit()
    # https://docs.python.org/3/library/email.examples.html